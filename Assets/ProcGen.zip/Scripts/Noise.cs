using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Noise
{
    //public static void Get
}
